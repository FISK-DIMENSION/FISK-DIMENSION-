
document.addEventListener("DOMContentLoaded", () => {
    console.log("FISK DIMENSION PLATFORM – SYSTEM ONLINE");

    const avatarUpload = document.getElementById('avatar-upload');
    const preview = document.getElementById('preview');
    const loreTextarea = document.getElementById('lore-text');

    avatarUpload.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                preview.src = reader.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });
});

function updateLore() {
    const lore = document.getElementById("lore-text").value;
    alert("Lore Entry Saved: " + lore.substring(0, 100) + "...");
}
