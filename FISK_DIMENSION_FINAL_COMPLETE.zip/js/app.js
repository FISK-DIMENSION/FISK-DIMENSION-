
document.addEventListener("DOMContentLoaded", () => {
    console.log("FISK DIMENSION PLATFORM – SYSTEM ONLINE");
    const statusElements = document.querySelectorAll("section");
    statusElements.forEach(el => {
        el.addEventListener("click", () => {
            el.classList.toggle("active");
        });
    });
});
        